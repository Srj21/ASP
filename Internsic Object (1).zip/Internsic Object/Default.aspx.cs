﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DisplayInfoButton_Click(object sender, EventArgs e)
    {
        // Accessing the Request object
            Label1.Text = Request.UserAgent;

            // Accessing the Response object
            Response.Write("This is the Response object.<br />");

            // Accessing the Session object
            Session["UserName"] = "John Doe";
            

            // Accessing the Application object
            Application["AppInfo"] = "Intrinsic Objects Demo";

            // Accessing the Server object
            Label2.Text = Server.MachineName;

            // Accessing the Context object
            Label3.Text = Context.Request.Url.AbsoluteUri;

            Label4.Text = Session["UserName"].ToString();
            Label5.Text = Application["AppInfo"].ToString();
    }
}