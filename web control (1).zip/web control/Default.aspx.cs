﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Label1.Text = txtName.Text;
        Label2.Text = rblOptions.SelectedItem != null ? rblOptions.SelectedItem.Text : "";
        Label3.Text = string.Join(", ", cblItems.Items.Cast<System.Web.UI.WebControls.ListItem>().Where(li => li.Selected).Select(li => li.Text));
        Label4.Text = ddlColors.SelectedValue;

        
    }
}