﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
public partial class _Default : System.Web.UI.Page
{
    
    OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\IMRD\Desktop\DB.accdb");
    protected void Page_Load(object sender, EventArgs e)
    {
        GridView1.DataBind(); 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        OleDbCommand cmd = new OleDbCommand("insert into Table1 values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Data added sucesess');</script>");
        con.Close();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        DataTable dt = new DataTable();
        OleDbDataAdapter da = new OleDbDataAdapter("select * from Table1", con);
        da.Fill(dt);
        GridView1.DataSource=dt;
        GridView1.DataBind();
        con.Close();
    }
}